package org.ethereum.core.genesis;

public class AllocatedAccount {
    String balance;

    public AllocatedAccount() {
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}
