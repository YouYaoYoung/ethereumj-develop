package org.ethereum.vm.program.listener;

public interface ProgramListenerAware {
    
    void setProgramListener(ProgramListener listener);
}
