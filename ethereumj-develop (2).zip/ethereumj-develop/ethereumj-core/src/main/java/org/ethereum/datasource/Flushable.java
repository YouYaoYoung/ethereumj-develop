package org.ethereum.datasource;

/**
 * Created by Anton Nashatyrev on 17.03.2016.
 */
public interface Flushable {
    void flush();
}
